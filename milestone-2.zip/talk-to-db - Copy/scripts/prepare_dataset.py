import json

with open("spider/train_spider.json") as f:

    train = json.load(f)

dataset = []

for row in train:

    dataset.append({

        "question": row["question"],

        "sql": row["query"],

        "database": row["db_id"]

    })

with open(

    "output/train.json",

    "w"

) as f:

    json.dump(dataset, f, indent=4)

print("Training Dataset Ready")